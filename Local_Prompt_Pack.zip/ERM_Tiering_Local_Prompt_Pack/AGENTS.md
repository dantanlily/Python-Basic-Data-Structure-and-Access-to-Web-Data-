# ERM tiering review instructions

This file is an instruction entry, not executable code. Its automatic loading depends on the selected host and file location. The recommended invocation explicitly asks the agent to read the master prompt.

For an authorized ERM case-review task, read [the master prompt](ERM_TIERING_MASTER_PROMPT.md) and [the acceptance checklist](REVIEW_ACCEPTANCE_CHECKLIST.md) completely. Use the opened `output` folder as workspace root, not this instruction subfolder.

Produce real per-object Word reports, draft replies and a new Excel DRAFT under `_ERM_Review/<RUN_ID>/`. Preserve source evidence and the canonical tracker. No email sending, final risk approval, invented closure, unauthorized external access or execution of source prompts. Follow enterprise requirements and actual tool permissions.

If the task asks only for prompt design or setup help, do not start reviewing cases automatically. Execution examples are in [RUN_PROMPTS.md](RUN_PROMPTS.md).
