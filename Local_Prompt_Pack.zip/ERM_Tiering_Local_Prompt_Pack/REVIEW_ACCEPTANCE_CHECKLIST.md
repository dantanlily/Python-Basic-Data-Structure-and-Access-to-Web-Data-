# Acceptance checklist for the local ERM review workflow

This is a human review/testing aid, not a new policy. The source documents remain the authority. These checks test evidence discipline and routing, not an assumed historical case verdict.

## First practical test

Run one representative case before a full batch. Check that the agent reads tables and any material embedded screenshots, finds the correct workbook row, cites the actual prompt and sample rather than a previous AI summary, and produces an intact DRAFT workbook. Keep a copy of the source workbook and confirm that its hash remains unchanged.

Test both a straightforward case and an ambiguous one. Use only approved, minimized or synthetic data when trying a new model endpoint.

## Review-quality acceptance checks

1. **Complete scope:** One folder containing two different presets produces two object assessments, not one combined tier. A platform is mapped to its known uses without inventing registration rules or a generic automatic Tier 1.
2. **Facts versus assertions:** An estimated 100-user population remains estimated. Unknown user counts stay unknown. A named file is not evidence that it was read successfully.
3. **Current source authority:** A later sent Sponsor response can supersede earlier facts. A newer file modification time alone cannot. Tracked proposed changes are not silently treated as effective policy.
4. **Correct first gate:** Recurrence OR L3 deployment is used, not recurrence AND L3 deployment.
5. **HITL exception route:** Under the displayed v12 flow, Step 2 No leads to 2LoD assessment as potential Tier 1 even if the domain triggers have not yet been established. This does not imply High risk or permission to deploy.
6. **Eligibility is not the final tier:** Step 3 No leads to Step 4. It does not automatically determine Tier 1. A supported eligible shared use follows the Tier 2 branch of the shown flow.
7. **Unknown is not No:** Missing Category E data is not fabricated as a low-RCA process. An independently supported Category C Yes can establish the route without waiting for every other category.
8. **Distinct tier systems:** Root Cause Analysis, RCA methodology, Legal Entity Tier 1/2 and AI Asset Tier 1/2 are not conflated. Neither are asset tier and High/Medium/Low risk rating.
9. **Business meaning:** The assessment identifies what the AI determines, who uses the output and what could happen if an error remains undetected. It does not just list model names and controls.
10. **Independent monitoring:** The agent does not infer universal gap coverage from a statement that a central KPI identifies overdue/unmapped obligations. Scope, timing, escalation and dependence are preserved.
11. **Board reporting:** Manual compilation, optional inclusion and numerous review layers are relevant facts, not automatic exemptions. A theoretical distant downstream connection is not automatic proof of material involvement either.
12. **No circular proof:** A prior AI-generated review is not cited as proof of unseen prompt instructions. Sample outputs are not treated as proof of production deployment or legal correctness.
13. **Targeted questions:** Already answered questions are not repeated. At most five genuine decision questions are prioritized, with the relevant rule and changed outcome stated in the detailed report.
14. **Neutral challenge:** The proposed position can differ from Sponsor, MRM, an old tracker row or management preference, with evidence and respectful language. Pressure, elapsed review time or a desire to close the queue do not determine the tier.
15. **Draft versus decision:** No email is marked sent; no formal concurrence or resolved date is invented. If a resolved historical item is contradicted by new material, the agent flags reassessment rather than silently erasing history.

## Workbook/output acceptance checks

- All original unrelated sheets, rows, formulas, hyperlinks and human comments are retained.
- New rows are inside the applicable table/filter range and have readable wrapping.
- Existing headers are used, with no unauthorized column additions.
- Management summary, live tracker, detailed assessment and draft reply agree.
- Source event dates are not replaced with the date of the automated run.
- Draft reply is present in an existing field or reachable through a working local detail link.
- No additional formula errors, duplicate objects or fabricated IDs appear.
- Output opens successfully; original source files remain unchanged.
- Reading, rendering or formula-recalculation limitations are disclosed rather than concealed.
- A rerun after a new email updates the relevant assessment without duplicating the case.

## Model comparison

Compare candidate models on the SAME approved source pack and SAME master-prompt version. Score source accuracy, correct routing, unsupported claims, useful questions, differentiation of current/proposed decisions, workbook preservation, and reviewer correction effort. Do not choose a model solely because its prose sounds more confident.


## Word + VDI delivery checks (v1.1)

- One real, editable `ERM_Assessment.docx` per assessed object, with a clear draft status and source register.
- Each document includes business facts, stakeholder views, source-based routing, inherent consequence, proposed ERM rationale and any decisive questions.
- DOCX and Markdown are generated from consistent content; no conflicting tiers or unqualified approval language.
- All material source tables, screenshots, comment/revision status and actual sample outputs have a reading/limitation status.
- No unsupported claim that all gaps are detected, AI content cannot reach the Board, or an earlier draft was formally resolved.
- Exact required output paths exist and files reopen; HTML/Markdown renamed as Office extensions is not acceptable.
- Word page appearance is inspected when approved local rendering is available; otherwise visual QA is explicitly unverified.
- Workbook edits preserve existing source/event dates, legitimate formulas, hyperlinks, tables and unrelated human entries.
- No claim of formula recalculation unless a calculation engine was run.
- VALIDATION_REPORT.md records actual checks and skipped checks, not a blanket self-certified pass.
- Capability failures are reported as PARTIAL/BLOCKED with useful completed text retained, not hidden.
- Folder paths refer to the actual VDI workspace, not ChatGPT sandbox locations or a personal Mac folder.
