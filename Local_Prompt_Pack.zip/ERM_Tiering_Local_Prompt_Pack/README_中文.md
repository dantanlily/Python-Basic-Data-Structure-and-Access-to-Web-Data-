# VS Code / 公司 VDI：直接运行说明（v1.1）

## 先做这三步

1. 把本包解压后得到的整个 `ERM_Tiering_Local_Prompt_Pack` 文件夹，复制到**公司 VDI 的 `output` 目录内**，与 `Reference_Knowledge` 和现有 tracker 同级。不要只放在个人 Mac 的 Downloads；不要把它当成编号案例。此版本的 ZIP 文件名带 v2，但内层文件夹名不变。
2. 在公司 VS Code 中继续打开**整个 `output` 工作区**，保留可访问这些文件的本地执行目标，使用 **Agent** 和公司批准的 Claude 模型。截图里的模型选择不是终端命令，不需要输入 `agent cloud`，也不需要额外启动 Claude Code CLI。
3. 将 `00_START_IN_VSCODE.md` 中标题下面的英文完整粘贴到右侧 Chat 输入框并发送。不是粘贴到 Terminal。可用聊天的 Add Context、`#` 文件选择或拖拽附上主 prompt 文件。指令已经明确要求读取它，不依赖自动发现。

```text
output/
  ERM_AI_Tiering_Open_Items_Tracker.xlsx
  Reference_Knowledge/
  0001_.../
  0002_.../
  0004_.../
  0005_.../
  ERM_Tiering_Local_Prompt_Pack/
    00_START_IN_VSCODE.md
    ERM_TIERING_MASTER_PROMPT.md
    REVIEW_ACCEPTANCE_CHECKLIST.md
    RUN_PROMPTS.md
    AGENTS.md
    CLAUDE.md
```

不需要在 Terminal 逐个执行 Markdown。`AGENTS.md` / `CLAUDE.md` 都是指令文本，不是程序，也不是两个必须依次运行的 agents。它们是否自动加载取决于 VS Code 版本、选中的 agent harness、位置和设置。当前建议直接指定主 prompt 的路径。使用 Claude 模型并不意味着会话一定属于 Claude Code harness。

## 已有旧包怎么办

旧包以每案 Markdown 为主要输出。这次已补充真实 Word `.docx`、Word/Excel 一致性验证和 VDI 执行要求。保留旧包备份后替换**指令文件夹**即可；不要替换 `Reference_Knowledge`、案例或 tracker。如果仍然使用旧包，启动指令仍明确要求每案 Word，但推荐用本版避免交付要求不一致。

## 会生成什么

```text
_ERM_Review/<RUN_ID>/
  ERM_AI_Tiering_Open_Items_Tracker__DRAFT_<RUN_ID>.xlsx
  cases/<object_key>/
    ERM_Assessment.docx
    ERM_Assessment.md
    Draft_Reply.txt
    case_review.json
  source_register.json
  rule_register.json
  review_changes.csv
  run_manifest.json
  RUN_SUMMARY.md
  VALIDATION_REPORT.md
```

每个 case Word 要解释业务用途、输入输出、实际使用者、MRM 与 Sponsor 的观点、适用规则、初步 ERM 立场、未发现错误的具体后果、证据以及有必要才问的澄清问题。Excel 保留原来的表头与样式，主要结论写在表内，详情链接到 Word。

所有新判断都是等待你审核的提案。原始文件不覆盖，邮件不发送，没有明确批准就不移入 Resolved。此前 AI 生成的记录不能自动当作正式 closure 证据。

## 运行时注意

- 保留默认权限和企业限制。检查工具审批内容，仅批准任务需要、且在公司允许范围内的读文件/写草稿/本地处理操作。不要为了自动化打开 Bypass Approvals。
- `Local` 表示工具执行位置，并不证明模型在本地推理。先遵守公司对该模型端点和数据的许可。
- Prompt 不会安装 Python、解密受保护的 Office 文件或解除 DLP。能力不足时应列明缺口、交付已完成部分，不能假称成功。
- 如读取受到截断，应继续分段读取。关键截图不可读时必须标出来。
- 运行期间保持会话可用；需要审批或出现配额限制可能暂停。本包不是自动后台服务。
- 结束时确认 `.docx` 与 `.xlsx` 实际存在且可打开。只有脚本/计划/聊天文字不是完成。
- 本包已检查文件完整性和指令一致性，**没有在你的公司 VDI 实际运行或审阅截图中的新案例**。

## 后续运行

`RUN_PROMPTS.md` 有单案例、增量更新和中断恢复指令。相同 case 不应重复新增。增量更新要核对来源和规则哈希，不能把旧 DRAFT 自动当成正式 tracker。

## 官方工具文档（2026-09-24 核对）

以下只用于 VS Code 操作，不是内部 tiering 规则：
- Agent、模型与运行环境的区别：https://code.visualstudio.com/docs/agents/concepts/agent-harnesses
- 自定义指令加载：https://code.visualstudio.com/docs/agent-customization/custom-instructions
- 将文件加入聊天上下文：https://code.visualstudio.com/docs/chat/copilot-chat-context
- 工具与权限：https://code.visualstudio.com/docs/agents/run/approvals
- 安全及数据暴露：https://code.visualstudio.com/docs/agents/run/security
