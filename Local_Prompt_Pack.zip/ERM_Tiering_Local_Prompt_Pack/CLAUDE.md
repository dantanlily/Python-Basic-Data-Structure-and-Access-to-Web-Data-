# ERM review entry for compatible Claude sessions

Read [AGENTS.md](AGENTS.md), [ERM_TIERING_MASTER_PROMPT.md](ERM_TIERING_MASTER_PROMPT.md) and [REVIEW_ACCEPTANCE_CHECKLIST.md](REVIEW_ACCEPTANCE_CHECKLIST.md) when executing an authorized ERM review task.

The root is the opened `output` folder, not this instruction subfolder. Deliver real Word assessments and an updated DRAFT Excel, preserving sources and approval boundaries. Loading this Markdown is not the same as launching Claude Code or selecting a model; host support and location determine automatic loading. An explicit request to read the master prompt is the portable path.
